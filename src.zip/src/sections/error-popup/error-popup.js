;(function() {
  errorPopup = new Popup('.error-popup', {
    closeButtons: '.error-popup__btn'
  });
})();