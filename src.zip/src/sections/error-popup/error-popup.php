<div class="error-popup popup">
  <div class="error-popup__cnt popup__cnt">
    <img src="#" alt="ok" data-src="<?php echo $template_directory_uri ?>/img/icon-fail.svg" class="error-popup__status-icon popup__status-icon lazy">
    <p class="error-popup__title popup__title">Error!</p>
    <p class="error-popup__descr popup__descr">Something went wrong, try one more time</p>
    <button type="button" class="error-popup__btn popup__btn btn btn-ol-gradient">Ok</button>
  </div>
</div>