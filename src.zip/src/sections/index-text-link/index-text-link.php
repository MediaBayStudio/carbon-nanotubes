<section class="index-lf container sect-bg">
  <h2 class="index-lf__title sect-title"><?php echo $section['text'] ?></h2>
  <a href="<?php echo $section['link']['url'] ?>" class="index-lf__link btn btn-ol-white"><span class="btn-text"><?php echo $section['link']['title'] ?></span></a>
</section>