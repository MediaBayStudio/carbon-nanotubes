<section class="tokenomics-hero container">
  <span class="tokenomics-hero__top-text sect-top-text"><?php echo $section['upper_text'] ?></span>
  <h1 class="tokenomics-hero__title"><?php echo $section['title'] ?></h1>
  <a href="<?php echo $section['link']['url'] ?>" class="tokenomics-hero__link btn btn-gradient" target="_blank"><?php echo $section['link']['title'] ?></a>
</section>