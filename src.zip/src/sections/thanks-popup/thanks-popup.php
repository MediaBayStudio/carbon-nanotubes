<div class="thanks-popup popup">
  <div class="thanks-popup__cnt popup__cnt">
    <img src="#" alt="ok" data-src="<?php echo $template_directory_uri ?>/img/icon-ok.svg" class="thanks-popup__status-icon popup__status-icon lazy">
    <p class="thanks-popup__title popup__title">Thank you!</p>
    <p class="thanks-popup__descr popup__descr">Your message was sent successfully</p>
    <button type="button" class="thanks-popup__btn popup__btn btn btn-ol-gradient">Ok</button>
  </div>
</div>