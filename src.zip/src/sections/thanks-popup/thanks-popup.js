;(function() {
  thanksPopup = new Popup('.thanks-popup', {
    closeButtons: '.thanks-popup__btn'
  });
})();