document.addEventListener('DOMContentLoaded', function() {

//=include ../sections/header/header.js

//=include ../sections/mobile-menu/mobile-menu.js

//=include ../sections/tokenomics-hero/tokenomics-hero.js

//=include ../sections/tokenomics-ctube/tokenomics-ctube.js

//=include ../sections/tokenomics-token-distribution-model/tokenomics-token-distribution-model.js

//=include ../sections/title-descr-link/title-descr-link.js

//=include ../sections/footer/footer.js

});