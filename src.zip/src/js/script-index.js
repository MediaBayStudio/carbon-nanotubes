document.addEventListener('DOMContentLoaded', function() {

//=include ../sections/header/header.js

//=include ../sections/mobile-menu/mobile-menu.js

//=include ../sections/index-hero/index-hero.js

//=include ../sections/index-about/index-about.js

//=include ../sections/index-perspective/index-perspective.js

//=include ../sections/index-text-link/index-text-link.js

//=include ../sections/index-faq/index-faq.js

//=include ../sections/index-contacts/index-contacts.js

//=include ../sections/thanks-popup/thanks-popup.js

//=include ../sections/error-popup/error-popup.js

//=include ../sections/footer/footer.js

});