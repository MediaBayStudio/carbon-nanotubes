document.addEventListener('DOMContentLoaded', function() {

//=include ../sections/header/header.js

//=include ../sections/mobile-menu/mobile-menu.js

//=include ../sections/research-and-development-hero/research-and-development-hero.js

//=include ../sections/research-and-development-descr/research-and-development-descr.js

//=include ../sections/research-and-development-projects/research-and-development-projects.js

//=include ../sections/research-and-development-properties/research-and-development-properties.js

//=include ../sections/research-and-development-more-applications/research-and-development-more-applications.js

//=include ../sections/title-descr-link/title-descr-link.js

//=include ../sections/footer/footer.js

});